/**
 * Contains abstract classes which should be extended by a particular release, allowing for portability between various protocol and client releases.
 */
package org.apollo.net.release;

