/**
 * Contains classes related to networking. Many of these extend Netty's set of classes - such as the pipeline factory, handler and codecs.
 */
package org.apollo.net;

