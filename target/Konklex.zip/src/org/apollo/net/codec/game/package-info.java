/**
 * Contains codecs for the game protocol.
 */
package org.apollo.net.codec.game;

