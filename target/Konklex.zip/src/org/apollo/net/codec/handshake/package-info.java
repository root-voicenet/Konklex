/**
 * Contains codecs for the handshake protocol.
 */
package org.apollo.net.codec.handshake;

