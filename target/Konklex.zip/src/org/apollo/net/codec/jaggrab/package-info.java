/**
 * Contains codecs for the JAGGRAB protocol.
 */
package org.apollo.net.codec.jaggrab;

