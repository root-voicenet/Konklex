/**
 * Contains codecs for the login protocol.
 */
package org.apollo.net.codec.login;

