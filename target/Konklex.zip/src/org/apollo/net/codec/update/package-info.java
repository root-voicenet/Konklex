/**
 * Contains codecs for the ondemand (update) protocol.
 */
package org.apollo.net.codec.update;

