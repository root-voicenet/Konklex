/**
 * Contains classes which contain meta data about the protocol/various packets.
 */
package org.apollo.net.meta;

