/**
 * Provides {@link Method}'s for the Frontend {@link Manager}
 */
package org.apollo.backend.method.impl;