/**
 * Provides handlers for the {@link FrontEnd}
 */
package org.apollo.backend.method.handler;