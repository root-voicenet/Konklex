/**
 * Provides {@link FrontendHandler}'s for the Frontend {@link Manager}
 */
package org.apollo.backend.method.handler.impl;