/**
 * Provides utilities for the Frontend {@link Manager}.
 */
package org.apollo.backend.util;