/**
 * Provides the main Frontend core.
 */
package org.apollo.backend;