/**
 * Provides {@link Action}'s
 */
package org.apollo.game.action.impl;