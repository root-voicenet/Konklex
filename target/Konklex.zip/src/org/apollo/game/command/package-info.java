/**
 * Provides a command base for the Apollo world.
 */
package org.apollo.game.command;