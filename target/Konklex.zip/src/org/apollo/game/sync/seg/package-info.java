/**
 * Contains classes related to synchronization segments. Each segment contains multiple blocks and can be used to add, remove, teleport or move a character.
 */
package org.apollo.game.sync.seg;

