/**
 * Contains classes related to {@link org.apollo.game.sync.task.SynchronizationTask}s, small chunks of work executed during the client synchronization process.
 */
package org.apollo.game.sync.task;

