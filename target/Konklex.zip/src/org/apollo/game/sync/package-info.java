/**
 * Contains classes related to client synchronization - the process where the client's state is updated by the server so it matches the server's state.
 */
package org.apollo.game.sync;

