package org.apollo.game.event;

/**
 * Represents an event that can occur in the game world.
 * @author Graham
 */
public abstract class Event {
}
