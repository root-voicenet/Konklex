/**
 * Contains classes related to the chaining of event handlers.
 */
package org.apollo.game.event.handler.chain;

