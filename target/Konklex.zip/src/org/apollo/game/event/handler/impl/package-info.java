/**
 * Contains event handler implementations.
 */
package org.apollo.game.event.handler.impl;

