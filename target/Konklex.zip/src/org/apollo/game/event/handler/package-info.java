/**
 * Contains classes which define abstract event handlers.
 */
package org.apollo.game.event.handler;

