/**
 * Contains event implementations.
 */
package org.apollo.game.event.impl;

