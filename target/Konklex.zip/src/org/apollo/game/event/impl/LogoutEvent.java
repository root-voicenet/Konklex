package org.apollo.game.event.impl;

import org.apollo.game.event.Event;

/**
 * An event sent to the client which logs it out cleanly.
 * @author Graham
 */
public final class LogoutEvent extends Event {
}
