/**
 * Contains classes related to the event management in the game.
 */
package org.apollo.game.event;

