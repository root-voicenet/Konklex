/**
 * Contains scheduled task implementations.
 */
package org.apollo.game.scheduling.impl;

