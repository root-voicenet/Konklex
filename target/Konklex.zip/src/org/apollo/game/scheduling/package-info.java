/**
 * Contains classes related to scheduling which allow tasks to be executed in future pulses periodically.
 */
package org.apollo.game.scheduling;

