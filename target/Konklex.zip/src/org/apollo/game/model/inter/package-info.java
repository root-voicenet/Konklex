/**
 * Contains interface listeners.
 */
package org.apollo.game.model.inter;

