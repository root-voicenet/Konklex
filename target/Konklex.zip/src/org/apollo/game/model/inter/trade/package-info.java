/**
 * Provides a trade base for the game world.
 */
package org.apollo.game.model.inter.trade;