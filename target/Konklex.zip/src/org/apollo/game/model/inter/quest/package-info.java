/**
 * Contains classes related to the quest interfaces.
 */
package org.apollo.game.model.inter.quest;

