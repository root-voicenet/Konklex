/**
 * Contains minigame-related utilities.
 */
package org.apollo.game.model.inter.minigame.util;