/**
 * Contains minigame-related classes.
 */
package org.apollo.game.model.inter.minigame;