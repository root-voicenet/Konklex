/**
 * Provides a core of melee based actions.
 */
package org.apollo.game.model.inter.melee;