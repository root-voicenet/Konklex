/**
 * Contains dialogue-related classes.
 */
package org.apollo.game.model.inter.dialog;