/**
 * Contains bank-related classes.
 */
package org.apollo.game.model.inter.bank;

