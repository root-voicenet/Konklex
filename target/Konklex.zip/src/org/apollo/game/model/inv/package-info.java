/**
 * Contains inventory listeners.
 */
package org.apollo.game.model.inv;

