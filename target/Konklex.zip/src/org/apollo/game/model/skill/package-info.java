/**
 * Contains skill listeners.
 */
package org.apollo.game.model.skill;

