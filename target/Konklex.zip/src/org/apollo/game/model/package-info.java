/**
 * Contains classes which represent things in the in-game world such as items, players and NPCs.
 */
package org.apollo.game.model;

