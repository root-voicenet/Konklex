package org.apollo.game.model.region;

/**
 * Manages the repository of regions.
 * @author Graham
 */
public class RegionRepository {
}