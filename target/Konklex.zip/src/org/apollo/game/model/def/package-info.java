/**
 * Contains definition classes which contain information about types of items, NPCs, etc.
 */
package org.apollo.game.model.def;

