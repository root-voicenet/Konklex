/**
 * Contains classes which parse files within the game's cache.
 */
package org.apollo.fs.parser;

