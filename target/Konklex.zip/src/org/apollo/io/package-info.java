/**
 * Contains classes which deal with input/output.
 */
package org.apollo.io;

