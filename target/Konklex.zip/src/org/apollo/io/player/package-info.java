/**
 * Contains classes which deal with loading and saving player files.
 */
package org.apollo.io.player;

