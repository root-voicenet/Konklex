/**
 * Contains various player loader/saver implementations.
 */
package org.apollo.io.player.impl;

