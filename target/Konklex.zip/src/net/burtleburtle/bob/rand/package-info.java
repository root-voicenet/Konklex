/**
 * Contains a Java implementation of Bob Jenkins' ISAAC algorithm.
 */
package net.burtleburtle.bob.rand;

